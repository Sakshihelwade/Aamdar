export const menuItems = [
  // {
  //   isHeadr: true,
  //   title: "menu",
  // },

  {
    title: "मुखपृष्ठ",
    icon: "heroicons-outline:home",
    link: "dashboard",
    isOpen: true,
    isHide: true,
  },
  {
    title: "रिपोर्ट 1 ",
    icon: "heroicons-outline:table",
    link: "vendor-list",
    isOpen: true,
    isHide: true,
    child: [
      {
        childtitle: "नावानुसार यादी",
        childlink: "Namewiselist",
      },
      {
        childtitle: "अल्फाबेटिकल यादी ",
        childlink: "Alphabeticalwise",
      },
      {
        childtitle: "पत्त्यानुसार  यादी",
        childlink: "Addresswise",
      },
      {
        childtitle: "आडनावानुसार यादी",
        childlink: "Surnamewise",
      },
      {
        childtitle: "वयानुसार यादी",
        childlink: "Agewise",
      },
      {
        childtitle: "कुटुंबानुसार यादी",
        childlink: "Familywise",
      },
      {
        childtitle: "जातीनुसार यादी",
        childlink: "Castwise",
      },
      {
        childtitle: "मोबाईल नंबरनुसार यादी",
        childlink: "MobileNoWise",
      },
      {
        childtitle: "गट गणनुसार गाव यादी",
        childlink: "GathGanWiseVillage",
      },
    ],
  },
  {
    title: "रिपोर्ट 2 ",
    icon: "heroicons-outline:table",
    link: "vendo-list",
    isOpen: true,
    isHide: true,
    child: [
      {
        childtitle: "  दुबार",
        childlink: "dubar",
      },
      {
        childtitle: "जन्मतारखेनुसार ",
        childlink: "by-dob-report2",
      },
      // {
      //   childtitle: " लग्नाचा वाढदिवस",
      //   childlink: "by-marriage-anniversary-report2",
      // },
      // {
      //   childtitle: "पुरवणी संक्षिप्त मतदार",
      //   childlink: "by-supplementary",
      // },
      // {
      //   childtitle: "बदललेले पत्त्यानुसार",
      //   childlink: "by-changed-address",
      // },
      // {
      //   childtitle: "व्यवसायानुसार",
      //   childlink: "by-business",
      // },
      // {
      //   childtitle: " संदर्भानुसार",
      //   childlink: "by-context",
      // },
    ],
  },
  {
    title: "नियोजन",
    icon: "heroicons-outline:table",
    link: "vendo-list",
    isOpen: true,
    isHide: true,
    child: [
      {
        childtitle: "रेड / ग्रीन मतदार",
        childlink: "red-green-voter",
      },
      // {
      //   childtitle: "यादी कमिटी ",
      //   childlink: "yadi-committee",
      // },
      // {
      //   childtitle: "कार्यकर्त्यानुसार",
      //   childlink: "karyakartyanusar",
      // },
      {
        childtitle: "जिवंत / मृत",
        childlink: "jivant-mrut",
      },
      // {
      //   childtitle: "सर्वे निकाल",
      //   childlink: "survey-result",
      // },
    ],
  },
  {
    title: "इतर फिल्टर",
    icon: "heroicons-outline:table",
    link: "Filter",
    isOpen: true,
    isHide: true,
  },
  {
    title: "गट गणनुसार",
    icon: "heroicons-outline:table",
    link: "GatGanSummary",
    isOpen: true,
    isHide: true,
  },
  {
    title: "अहवाल",
    icon: "heroicons-outline:table",
    link: "ahawal",
    isOpen: true,
    isHide: true,
  },
  // {
  //   title: "सर्वे ",
  //   icon: "heroicons-outline:table",
  //   link: "vendo-list",
  //   isOpen: true,
  //   isHide: true,
  //   child: [
  //     {
  //       childtitle: "मास्टर मोबाईल",
  //       childlink: "master-mobile",
  //     },
  //     {
  //       childtitle: "सर्वे रजिस्ट्रेशन",
  //       childlink: "survey-registration",
  //     },
  //     {
  //       childtitle: "फोटो सिंक्रोनाईज",
  //       childlink: "photo-synchronize",
  //     },
  //     {
  //       childtitle: "सर्वे डेटा पाहणे",
  //       childlink: "view-survey-data",
  //     },
  //     {
  //       childtitle: "लोकेशन असणारे",
  //       childlink: "with-location",
  //     },
  //     {
  //       childtitle: "सर्वे झालेले न झालेले",
  //       childlink: "surveyed-or-unsurveyed",
  //     },
  //     {
  //       childtitle: "नवीन मतदार",
  //       childlink: "new-voters",
  //     },
  //   ],
  // },
  {
    title: "Meta Data ",
    icon: "heroicons-outline:table",
    // link: "vendo-list",
    isOpen: true,
    isHide: true,
    child: [
      {
        childtitle: "जात",
        childlink: "Caste-Meta-Data",
      },
      {
        childtitle: "रंग",
        childlink: "color",
      },
      // {
      //   childtitle: "कार्यकर्ता",
      //   childlink: "New-Karyakarta",
      // },
      {
        childtitle: "व्यवसाय",
        childlink: "Business",
      },
      {
        childtitle: "नगर",
        childlink: "Nagar",
      },
      {
        childtitle: "योजना",
        childlink: "Yojana",
      },
      {
        childtitle: " जवळचे ठिकाण",
        childlink: "Landmark",
      },
      {
        childtitle: "सोसायटी",
        childlink: "Society",
      },
      // {
      //   childtitle: "Sahdharbh",
      //   childlink: "by-dob-report2",
      // },
    ]
  },
  {
    title: "Export PDF",
    icon: "heroicons-outline:table",
    link: "export-pdf",
    isOpen: true,
    isHide: true,
  },


];

export const topMenu = [
  {
    title: "मुखपृष्ठ",
    icon: "heroicons-outline:home",
    link: "/app/home",
    child: [
      {
        childtitle: "Analytics Dashboard",
        childlink: "dashboard",
        childicon: "heroicons:presentation-chart-line",
      },
      {
        childtitle: "Ecommerce Dashboard",
        childlink: "ecommerce",
        childicon: "heroicons:shopping-cart",
      },
      {
        childtitle: "Project  Dashboard",
        childlink: "project",
        childicon: "heroicons:briefcase",
      },
      {
        childtitle: "CRM Dashboard",
        childlink: "crm",
        childicon: "ri:customer-service-2-fill",
      },
      {
        childtitle: "Banking Dashboard",
        childlink: "banking",
        childicon: "heroicons:wrench-screwdriver",
      },
    ],
  },
  {
    title: "App",
    icon: "heroicons-outline:chip",
    link: "/app/home",
    child: [
      {
        childtitle: "Calendar",
        childlink: "calender",
        childicon: "heroicons-outline:calendar",
      },
      {
        childtitle: "Kanban",
        childlink: "kanban",
        childicon: "heroicons-outline:view-boards",
      },
      {
        childtitle: "Todo",
        childlink: "todo",
        childicon: "heroicons-outline:clipboard-check",
      },
      {
        childtitle: "Projects",
        childlink: "projects",
        childicon: "heroicons-outline:document",
      },
    ],
  },

];

import User1 from "@/assets/images/all-img/user.png";
import User2 from "@/assets/images/all-img/user2.png";
import User3 from "@/assets/images/all-img/user3.png";
import User4 from "@/assets/images/all-img/user4.png";
export const notifications = [
  {
    title: "Your order is placed",
    desc: "Amet minim mollit non deser unt ullamco est sit aliqua.",

    image: User1,
    link: "#",
  },
  {
    title: "Congratulations Darlene  🎉",
    desc: "Won the monthly best seller badge",
    unread: true,
    image: User2,
    link: "#",
  },
  {
    title: "Revised Order 👋",
    desc: "Won the monthly best seller badge",

    image: User3,
    link: "#",
  },
  {
    title: "Brooklyn Simmons",
    desc: "Added you to Top Secret Project group...",

    image: User4,
    link: "#",
  },
];

export const message = [
  {
    title: "Wade Warren",
    desc: "Hi! How are you doing?.....",
    active: true,
    hasnotifaction: true,
    notification_count: 1,
    image: User1,
    link: "#",
  },
  {
    title: "Savannah Nguyen",
    desc: "Hi! How are you doing?.....",
    active: false,
    hasnotifaction: false,
    image: User2,
    link: "#",
  },
  {
    title: "Ralph Edwards",
    desc: "Hi! How are you doing?.....",
    active: false,
    hasnotifaction: true,
    notification_count: 8,
    image: User3,
    link: "#",
  },
  {
    title: "Cody Fisher",
    desc: "Hi! How are you doing?.....",
    active: true,
    hasnotifaction: false,
    image: User4,
    link: "#",
  },
  {
    title: "Savannah Nguyen",
    desc: "Hi! How are you doing?.....",
    active: false,
    hasnotifaction: false,
    image: User2,
    link: "#",
  },
  {
    title: "Ralph Edwards",
    desc: "Hi! How are you doing?.....",
    active: false,
    hasnotifaction: true,
    notification_count: 8,
    image: User3,
    link: "#",
  },
  {
    title: "Cody Fisher",
    desc: "Hi! How are you doing?.....",
    active: true,
    hasnotifaction: false,
    image: User4,
    link: "#",
  },
];

export const colors = {
  primary: "#4669FA",
  secondary: "#A0AEC0",
  danger: "#F1595C",
  black: "#111112",
  warning: "#FA916B",
  info: "#0CE7FA",
  light: "#425466",
  success: "#50C793",
  "gray-f7": "#F7F8FC",
  dark: "#1E293B",
  "dark-gray": "#0F172A",
  gray: "#68768A",
  gray2: "#EEF1F9",
  "dark-light": "#CBD5E1",
};

export const hexToRGB = (hex, alpha) => {
  var r = parseInt(hex.slice(1, 3), 16),
    g = parseInt(hex.slice(3, 5), 16),
    b = parseInt(hex.slice(5, 7), 16);

  if (alpha) {
    return "rgba(" + r + ", " + g + ", " + b + ", " + alpha + ")";
  } else {
    return "rgb(" + r + ", " + g + ", " + b + ")";
  }
};

export const topFilterLists = [
  {
    name: "Inbox",
    value: "all",
    icon: "uil:image-v",
  },
  {
    name: "Starred",
    value: "fav",
    icon: "heroicons:star",
  },
  {
    name: "Sent",
    value: "sent",
    icon: "heroicons-outline:paper-airplane",
  },

  {
    name: "Drafts",
    value: "drafts",
    icon: "heroicons-outline:pencil-alt",
  },
  {
    name: "Spam",
    value: "spam",
    icon: "heroicons:information-circle",
  },
  {
    name: "Trash",
    value: "trash",
    icon: "heroicons:trash",
  },
];

export const bottomFilterLists = [
  {
    name: "personal",
    value: "personal",
    icon: "heroicons:chevron-double-right",
  },
  {
    name: "Social",
    value: "social",
    icon: "heroicons:chevron-double-right",
  },
  {
    name: "Promotions",
    value: "promotions",
    icon: "heroicons:chevron-double-right",
  },
  {
    name: "Business",
    value: "business",
    icon: "heroicons:chevron-double-right",
  },
];

import meetsImage1 from "@/assets/images/svg/sk.svg";
import meetsImage2 from "@/assets/images/svg/path.svg";
import meetsImage3 from "@/assets/images/svg/dc.svg";
import meetsImage4 from "@/assets/images/svg/sk.svg";

export const meets = [
  {
    img: meetsImage1,
    title: "Meeting with client",
    date: "01 Nov 2021",
    meet: "Zoom meeting",
  },
  {
    img: meetsImage2,
    title: "Design meeting (team)",
    date: "01 Nov 2021",
    meet: "Skyp meeting",
  },
  {
    img: meetsImage3,
    title: "Background research",
    date: "01 Nov 2021",
    meet: "Google meeting",
  },
  {
    img: meetsImage4,
    title: "Meeting with client",
    date: "01 Nov 2021",
    meet: "Zoom meeting",
  },
];
import file1Img from "@/assets/images/icon/file-1.svg";
import file2Img from "@/assets/images/icon/pdf-1.svg";
import file3Img from "@/assets/images/icon/zip-1.svg";
import file4Img from "@/assets/images/icon/pdf-2.svg";
import file5Img from "@/assets/images/icon/scr-1.svg";

export const files = [
  {
    img: file1Img,
    title: "Dashboard.fig",
    date: "06 June 2021 / 155MB",
  },
  {
    img: file2Img,
    title: "Ecommerce.pdf",
    date: "06 June 2021 / 155MB",
  },
  {
    img: file3Img,
    title: "Job portal_app.zip",
    date: "06 June 2021 / 155MB",
  },
  {
    img: file4Img,
    title: "Ecommerce.pdf",
    date: "06 June 2021 / 155MB",
  },
  {
    img: file5Img,
    title: "Screenshot.jpg",
    date: "06 June 2021 / 155MB",
  },
];

import React from 'react'

const WithLocation = () => {
  return (
    <div>
      
    </div>
  )
}

export default WithLocation

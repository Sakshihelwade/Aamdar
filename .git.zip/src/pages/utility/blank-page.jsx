import React from "react";

const BalnkPage = () => {
  return (
    <div>
      <h4 className="font-medium lg:text-2xl text-xl capitalize text-slate-900 inline-block ltr:pr-4 rtl:pl-4 mb-6">
        Blank Page
      </h4>
    </div>
  );
};

export default BalnkPage;
